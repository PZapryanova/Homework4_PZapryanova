
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;


public class CheckBoxTest {
    WebDriver cbDriver;

    @BeforeMethod
    public void setUp () {
        System.setProperty("webdriver.chrome.driver", "D:\\drivers\\chromedriver.exe");
        ChromeOptions cbOptions = new ChromeOptions();
        cbOptions.addArguments("--start-maximized", "--disable-extensions");
        cbDriver = new ChromeDriver();
        cbDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        cbDriver.get("http://pragmatic.bg/automation/lecture13/Config.html");
    }

    @AfterMethod
    public void tearDown () {cbDriver.quit();}


    @Test
    public void checkBoxTest () {
        WebElement airBagsElement = cbDriver.findElement(By.name("airbags"));
        String airBags = airBagsElement.getAttribute("value");
        Assert.assertEquals(airBags, "Airbags");

        WebElement parkSensorElement = cbDriver.findElement(By.name("parksensor"));
        String parkSensor = parkSensorElement.getAttribute("value");
        Assert.assertEquals(parkSensor, "ParkingSensor");

        Actions cbBuilder = new Actions(cbDriver);
        cbBuilder.click(airBagsElement).perform();
        cbBuilder.click(parkSensorElement).perform();

        Assert.assertTrue(airBagsElement.isSelected());
        Assert.assertTrue(parkSensorElement.isSelected());
    }
}
