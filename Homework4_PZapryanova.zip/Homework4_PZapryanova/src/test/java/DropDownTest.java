
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;


public class DropDownTest {
    WebDriver ddDriver;

    @BeforeMethod
    public void setUp () {
        System.setProperty("webdriver.chrome.driver", "D:\\drivers\\chromedriver.exe");
        ChromeOptions ddOptions = new ChromeOptions();
        ddOptions.addArguments("--start-maximized", "--disable-extensions");
        ddDriver = new ChromeDriver();
        ddDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        ddDriver.get("http://shop.pragmatic.bg/admin");
    }

    @AfterMethod
    public void tearDown () {
        ddDriver.quit();
    }


    @Test
    public void dropDownTest () {

        WebElement userNameElement = ddDriver.findElement(By.id("input-username"));
        WebElement passwordElement = ddDriver.findElement(By.id("input-password"));
        String username = userNameElement.getAttribute("name");
        Assert.assertEquals(username, "username");
        String password = passwordElement.getAttribute("name");
        Assert.assertEquals(password,"password");
        userNameElement.sendKeys("admin");
        passwordElement.sendKeys("parola123!");
        WebElement loginElement = ddDriver.findElement(By.xpath("//div[@id='content']//div[@class='panel-body']//button[@type=\"submit\"]"));
        loginElement.click();
        WebElement loginAssert = ddDriver.findElement(By.id("user-profile"));
        String login = loginAssert.getAttribute("alt");
        Assert.assertEquals("Milen Strahinski", login);

        WebElement sales = ddDriver.findElement(By.xpath("//li[@id=\"menu-sale\"]/a"));
        sales.click();
        WebElement orders = ddDriver.findElement(By.xpath("//ul[@id=\"collapse4\"]//following-sibling::a[contains(@href,\"order\")]"));
        orders.click();

        Select orderStatus = new Select(ddDriver.findElement(By.id("input-order-status")));

        Assert.assertFalse(orderStatus.isMultiple());
        Assert.assertEquals(orderStatus.getOptions().size(), 16);

        List <String> exp_options = Arrays.asList(new String[] {"","Missing Orders", "Canceled", "Canceled Reversal",
                "Chargeback", "Complete", "Denied", "Expired", "Failed", "Pending", "Processed", "Processing",
                "Refunded", "Reversed", "Shipped", "Voided"});

        List <String> act_options = new ArrayList<String>();

        for (WebElement option : orderStatus.getOptions())
            act_options.add(option.getText());

        Assert.assertEquals(act_options.toArray(), exp_options.toArray());
    }
}
